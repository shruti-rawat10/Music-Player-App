package internshala.com.echo.activities

import android.os.Bundle
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import internshala.com.echo.R
import internshala.com.echo.activities.MainActivity.Statified.drawerLayout
import internshala.com.echo.adapters.NavigationDrawerAdapter
import internshala.com.echo.fragments.MainScreenFragment
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    var navigationDrawerIconsList:ArrayList<String> = arrayListOf()
    var imagesfornavdrawer=intArrayOf(R.drawable.navigation_allsongs,R.drawable.navigation_favorites,R.drawable.navigation_settings,
        R.drawable.navigation_aboutus)

object Statified{
    var drawerLayout: DrawerLayout? = null
}


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        MainActivity.Statified.drawerLayout = findViewById(R.id.drawer_layout)

navigationDrawerIconsList.add("All Songs")
         navigationDrawerIconsList.add("Favorite")
        navigationDrawerIconsList.add("Settings")
        navigationDrawerIconsList.add("About Us")




        var toggle = ActionBarDrawerToggle(
            this@MainActivity,  MainActivity.Statified.drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        MainActivity.Statified.drawerLayout?.addDrawerListener(toggle)
        toggle.syncState()
        val mainScreenFragment = MainScreenFragment()
        this.supportFragmentManager.beginTransaction()
            .add(R.id.details_fragment, mainScreenFragment, "MainScreenFragment").commit()

        var navigationAdapter=NavigationDrawerAdapter(navigationDrawerIconsList,imagesfornavdrawer,this)
navigationAdapter.notifyDataSetChanged()


        var navigationrecyclerview=findViewById<RecyclerView>(R.id.navigation_recycler_view)
        navigationrecyclerview.layoutManager=LinearLayoutManager(this)
        navigationrecyclerview.itemAnimator=DefaultItemAnimator()
        navigationrecyclerview.adapter=navigationAdapter
        navigationrecyclerview.setHasFixedSize(true)
    }

    public override fun onStart() {
        super.onStart()
    }
}
